import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.SystemColor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Register extends JFrame {

	private JPanel contentPane;
	
	File f= new File("D:\\java project\\logindata");
	int ln;
	String first,uss,mob,ema,add,passs;
	private JTextField u;
	private JTextField n;
	private JTextField em;
	private JTextField m;
	private JPasswordField pass1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	void createFolder() {
		if(!f.exists()) {
			f.mkdirs();
			
		}
	}
	
	void readFile() {
		
		try {
			FileReader fr=new FileReader(f+"\\logins.txt");
			FileReader fr1=new FileReader(f+"\\logind.txt");
			System.out.println("File exsists");
		} catch (FileNotFoundException e) {
			
			try {
				FileWriter fw= new FileWriter(f+"\\logins.txt");
				System.out.println("File created");
				FileWriter fw1= new FileWriter(f+"\\logind.txt");
				System.out.println("File created");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.print("Error");
			}
		}
		
		
	}
	
	
	void addData(String us,String p,String name,String email,String mob) {
		
		try {
			RandomAccessFile raf= new RandomAccessFile(f+"\\logins.txt","rw");
			for(int i=0;i<ln;i++) {
				raf.readLine();
			}
			
			raf.writeBytes("\r\n");
			raf.writeBytes("\r\n");
			
			raf.writeBytes("UserName:"+us+"\r\n");
			raf.writeBytes("Password:"+p+"\r\n");
			raf.writeBytes("Name:"+name+"\r\n");	
			raf.writeBytes("Email:"+email+"\r\n");	
			raf.writeBytes("Mobile:"+mob+"\r\n");
				
			
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}

	
	void addDatav(String us,String pass,String name,String em,String p) {
		
		try {
			RandomAccessFile raf= new RandomAccessFile(f+"\\logind.txt","rw");
			for(int i=0;i<ln;i++) {
				raf.readLine();
			}
			
			raf.writeBytes("\r\n");
		
			
			
			raf.writeBytes(us+"\t");
			raf.writeBytes(pass+"\t");
			raf.writeBytes(name+"\t");	
			raf.writeBytes(em+"\t");	
			raf.writeBytes(p+"\t");
			
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}
		
	
	
void countLines() {
		
		try {
			ln=1;
			RandomAccessFile raf= new RandomAccessFile(f+"\\logins.txt","rw");
			for(int i=0;raf.readLine()!=null;i++) {
				ln++;
				
			}
			
			System.out.println("Number of lines "+ln);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
public void close() {
		
		WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}
	
	
	
	
	/**
	 * Create the frame.
	 */
	public Register() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 729, 779);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("REGISTER");
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int ch=JOptionPane.showConfirmDialog(null, "Are you sure the entered details are correct","Add User",JOptionPane.YES_NO_OPTION);
				if(ch==0) {
				close();
				LoginFramee f= new LoginFramee();
				f.setVisible(true);
				createFolder();
				readFile();
				countLines();
				addData(u.getText(),pass1.getText(),n.getText(),em.getText(),m.getText());
				addDatav(u.getText(),pass1.getText(),n.getText(),em.getText(),m.getText());}
			}
		});
		btnNewButton.setBounds(403, 655, 208, 54);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("RESET");
		btnNewButton_1.setBackground(new Color(255, 222, 173));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ch=JOptionPane.showConfirmDialog(null, "Are you sure you want to reset","Reset",JOptionPane.YES_NO_OPTION);
				if(ch==0) {
				u.setText("");
				pass1.setText("");
				n.setText("");
				em.setText("");
				m.setText("");
		
				}
			
			}
			
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_1.setBounds(96, 655, 208, 54);
		contentPane.add(btnNewButton_1);
		
		u = new JTextField();
		u.setFont(new Font("Tahoma", Font.BOLD, 19));
		u.setColumns(10);
		u.setBackground(Color.WHITE);
		u.setBounds(343, 130, 290, 43);
		contentPane.add(u);
		
		n = new JTextField();
		n.setFont(new Font("Tahoma", Font.BOLD, 19));
		n.setColumns(10);
		n.setBackground(Color.WHITE);
		n.setBounds(343, 329, 290, 43);
		contentPane.add(n);
		
		em = new JTextField();
		em.setFont(new Font("Tahoma", Font.BOLD, 19));
		em.setColumns(10);
		em.setBackground(Color.WHITE);
		em.setBounds(343, 427, 290, 43);
		contentPane.add(em);
		
		m = new JTextField();
		m.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				
				char t1 =e.getKeyChar();
				if(!(Character.isDigit(t1)))
				e.consume();
			}
		});
		m.setFont(new Font("Tahoma", Font.BOLD, 19));
		m.setColumns(10);
		m.setBackground(Color.WHITE);
		m.setBounds(343, 516, 290, 43);
		contentPane.add(m);
		
		JLabel Ss = new JLabel("USERNAME");
		Ss.setOpaque(true);
		Ss.setFont(new Font("Tahoma", Font.BOLD, 19));
		Ss.setBackground(new Color(255, 222, 173));
		Ss.setBounds(0, 119, 273, 65);
		contentPane.add(Ss);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD");
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1.setBounds(0, 217, 273, 65);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("NAME");
		lblNewLabel_1_1.setOpaque(true);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_1.setBounds(0, 318, 273, 65);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("EMAIL");
		lblNewLabel_1_2.setOpaque(true);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_2.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_2.setBounds(0, 416, 273, 65);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("MOBILE");
		lblNewLabel_1_3.setOpaque(true);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_3.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_3.setBounds(0, 505, 273, 65);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblRegistration = new JLabel("REGISTRATION");
		lblRegistration.setOpaque(true);
		lblRegistration.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblRegistration.setBackground(new Color(255, 222, 173));
		lblRegistration.setBounds(0, 22, 375, 65);
		contentPane.add(lblRegistration);
		
		pass1 = new JPasswordField();
		pass1.setBounds(343, 221, 290, 43);
		contentPane.add(pass1);
	}
}
