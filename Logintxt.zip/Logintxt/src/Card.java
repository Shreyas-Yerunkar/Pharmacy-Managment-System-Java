import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Card extends JFrame {

	private JPanel contentPane;
	private JTextField n;
	private JTextField no;
	private JTextField r;
	private JPasswordField cvv;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Card frame = new Card();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
public void close() {
		
		WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}
	/**
	 * Create the frame.
	 */
	public Card() {
		setBackground(SystemColor.activeCaption);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 755, 766);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CARD PAYMENT");
		lblNewLabel.setBackground(new Color(255, 222, 173));
		lblNewLabel.setOpaque(true);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setBounds(0, 74, 369, 76);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("NAME OF CARD HOLDER");
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1.setBounds(0, 235, 273, 65);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("CARD NUMBER");
		lblNewLabel_1_1.setOpaque(true);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_1.setBounds(0, 349, 273, 65);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("EXPIRY(MM/YY)");
		lblNewLabel_1_2.setOpaque(true);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_2.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_2.setBounds(0, 460, 273, 65);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("CVV");
		lblNewLabel_1_3.setOpaque(true);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_3.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_3.setBounds(0, 569, 273, 65);
		contentPane.add(lblNewLabel_1_3);
		
		n = new JTextField();
		n.setFont(new Font("Tahoma", Font.BOLD, 19));
		n.setBackground(Color.WHITE);
		n.setBounds(333, 250, 290, 43);
		contentPane.add(n);
		n.setColumns(10);
		
		no = new JTextField();	
		no.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				
				char y =e.getKeyChar();
				if(!(Character.isDigit(y)))
				e.consume();
			}
		});
		no.setFont(new Font("Tahoma", Font.BOLD, 19));
		no.setColumns(10);
		no.setBackground(Color.WHITE);
		no.setBounds(333, 360, 290, 43);
		contentPane.add(no);
		
		r = new JTextField();
		r.setFont(new Font("Tahoma", Font.BOLD, 19));
		r.setColumns(10);
		r.setBackground(Color.WHITE);
		r.setBounds(333, 471, 290, 43);
		contentPane.add(r);
		
		cvv = new JPasswordField();
		cvv.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				
				char g =e.getKeyChar();
				if(!(Character.isDigit(g)))
				e.consume();
			}
		});
		cvv.setBounds(333, 584, 295, 43);
		contentPane.add(cvv);
		
		JButton btnNewButton = new JButton("DONE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				
				if(n.getText().equals("")||no.getText().equals("")||r.getText().equals("")||cvv.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Enter all the Details");
				}
				
				else {
					
					
				int ch=JOptionPane.showConfirmDialog(null, "Are you sure the entered details are correct","Card Payment",JOptionPane.YES_NO_OPTION);
				if(ch==0) {
		
					
					String filepath= "D:\\java project\\orderdata\\orderdata.txt";
					File f=new File(filepath);
					try {
						PrintWriter pw = new PrintWriter(new FileWriter(f,true));
						pw.write("Card Payment");
						pw.write("\n");
						pw.close();
						
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
		
					
					File f1 = new File("D:\\java project\\receipt\\receipt.txt");
					
					try {
						FileWriter fw = new FileWriter(f1.getAbsoluteFile(),true);
						
			               fw.write("Payment Mode: Card Payment");
			               fw.close();
			             
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					
				close();
				Delivery c= new Delivery();
				c.setVisible(true);
				} 
				}
			}
		});
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.setBounds(310, 674, 176, 45);
		contentPane.add(btnNewButton);
	}
}
