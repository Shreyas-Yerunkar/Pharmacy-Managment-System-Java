import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;



import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.awt.event.ActionEvent;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;


public class User extends JFrame  {
	public User() {
		ie();
	}
	private JFrame frame;
	public JTable table;

	float cf=0;
	float dc;
	protected DefaultTableModel DefaultTableModel;
	private JTextField sea;
	private JTextField pi;
	private JTextField pn1;
	private JTextField pr;
	private JTextField ex;
	private JTextField ty;

public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					User frame = new User();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		}
		




private void ie() {
	
	
		JTable table = new JTable();

		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				
				int i=table.getSelectedRow();
				TableModel model=table.getModel();
				
				
				
				pi.setEditable(false);
				pn1.setEditable(false);
				pr.setEditable(false);
				ty.setEditable(false);
				ex.setEditable(false);
				
				
				
				
				pi.setText(model.getValueAt(i, 0).toString());
				pn1.setText(model.getValueAt(i, 1).toString());
				pr.setText(model.getValueAt(i, 2).toString());
				ty.setText(model.getValueAt(i, 3).toString());
				ex.setText(model.getValueAt(i, 4).toString());
				

				boolean a=table.isEditing();
				
				if(a==false) {
					
					JOptionPane.showMessageDialog(null,"Product Selected");
				}
				
			}
		});
		

		//DefaultTableModel model=new DefaultTableModel();
		
		JFrame frame= new JFrame("");
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.setBounds(100,100,769,865);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		

		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Product Id", "Product Name", "Price", "Type", "Expiry Date"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		table.setBackground(Color.white);
		table.setForeground(Color.black);
		table.setSelectionBackground(Color.MAGENTA);
		table.setGridColor(Color.red);
		table.setSelectionForeground(Color.white);
		table.setFont(new Font("Tahoma",Font.PLAIN,17));
		table.setRowHeight(30);
		table.setAutoCreateRowSorter(true);
		
		JScrollPane pane = new JScrollPane(table);
		pane.setVisible(true);
		
		pane.setForeground(Color.red);
		pane.setBackground(Color.white);
		pane.setBounds(10,77,722,473);
		frame.getContentPane().add(pane);
		Object[] row = new Object[5];
		
		JButton btnNewButton_3 = new JButton("View Medicines");
		btnNewButton_3.setBackground(new Color(255, 222, 173));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
	            String filepath = "D:\\java project\\medicinedata\\medicinedata.txt";
	            File file=new File(filepath);
	            try {
	                BufferedReader br = new BufferedReader(new FileReader(file));
	                String firstLine = br.readLine().trim();
	                String[] columnsName = firstLine.split("\n");
	                
	                DefaultTableModel model = (DefaultTableModel)table.getModel();
	                model.setColumnIdentifiers(columnsName);
	            	Object [] columns = { "Product Id","Product Name","Price","Type","Expiry Date"};
	            	model.setColumnIdentifiers(columns);
	            	table.setModel(model);
			
	                Object[] tableLines = br.lines().toArray();
	           
	                for(int i = 0; i < tableLines.length; i++)
	                {
	                    String line = tableLines[i].toString().trim();
	                    String[] dataRow = line.split("\t");
	                    model.addRow(dataRow);
	                }
	                

	            } catch (Exception e1) {
	 
	          }
	            btnNewButton_3.setEnabled(false);

	            }
	        });
	          

	        
		btnNewButton_3.setBounds(124, 766, 248, 46);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Proceed");
		btnNewButton_4.setBackground(new Color(255, 222, 173));
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(table.getSelectionModel().isSelectionEmpty()) {
					JOptionPane.showMessageDialog(null, "Cannot Proceed Without the Selection of Medicines");
				}
				
				else {
				   
		        TableModel model1 =table.getModel();
		        int ind[] = table.getSelectedRows();
		        
		        Object[] row = new Object[5];
		        DefaultTableModel model = (DefaultTableModel)table.getModel();
 
		        Buy1 r = new Buy1();
		        DefaultTableModel model2 = (DefaultTableModel)r.tablee.getModel();
		        
		        for(int i = 0; i < ind.length; i++)
		        {
		            row[0] = model1.getValueAt(ind[i], 0);
		            row[1] = model1.getValueAt(ind[i], 1);
		            row[2] = model1.getValueAt(ind[i], 2);
		            row[3] = model1.getValueAt(ind[i], 3);
		            row[4] = model1.getValueAt(ind[i], 4);
		            
		            model2.addRow(row);
		        }
		        r.setVisible(true);
		        btnNewButton_4.setEnabled(false);
		    }  
			}
		});
		btnNewButton_4.setBounds(430, 766, 248, 46);
		frame.getContentPane().add(btnNewButton_4);
		
		JLabel lblSearch = new JLabel("Search");
		lblSearch.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblSearch.setBounds(430, 15, 109, 42);
		frame.getContentPane().add(lblSearch);
		
		sea = new JTextField();
		sea.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				String search =sea.getText();
				TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(model);
				table.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
		
			}
		});
		sea.setFont(new Font("Tahoma", Font.BOLD, 19));
		sea.setColumns(10);
		sea.setBounds(531, 21, 175, 32);
		frame.getContentPane().add(sea);
		
		JLabel lblProductId = new JLabel("Product Id");
		lblProductId.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblProductId.setBounds(10, 568, 152, 42);
		frame.getContentPane().add(lblProductId);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblPrice.setBounds(10, 630, 152, 42);
		frame.getContentPane().add(lblPrice);
		
		JLabel lblProductName = new JLabel("Product Name");
		lblProductName.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblProductName.setBounds(363, 568, 152, 42);
		frame.getContentPane().add(lblProductName);
		
		JLabel lblExpiryDate = new JLabel("Expiry Date");
		lblExpiryDate.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblExpiryDate.setBounds(363, 630, 152, 42);
		frame.getContentPane().add(lblExpiryDate);
		
		pi = new JTextField();
		pi.setFont(new Font("Tahoma", Font.BOLD, 19));
		pi.setColumns(10);
		pi.setBounds(153, 580, 175, 32);
		frame.getContentPane().add(pi);
		
		pn1 = new JTextField();
		pn1.setFont(new Font("Tahoma", Font.BOLD, 19));
		pn1.setColumns(10);
		pn1.setBounds(531, 578, 175, 32);
		frame.getContentPane().add(pn1);
		
		pr = new JTextField();
		pr.setFont(new Font("Tahoma", Font.BOLD, 19));
		pr.setColumns(10);
		pr.setBounds(153, 636, 175, 32);
		frame.getContentPane().add(pr);
		
		ex = new JTextField();
		ex.setFont(new Font("Tahoma", Font.BOLD, 19));
		ex.setColumns(10);
		ex.setBounds(531, 636, 175, 32);
		frame.getContentPane().add(ex);
		
		JLabel lblType = new JLabel("Type");
		lblType.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblType.setBounds(10, 692, 152, 42);
		frame.getContentPane().add(lblType);
		
		ty = new JTextField();
		ty.setFont(new Font("Tahoma", Font.BOLD, 19));
		ty.setColumns(10);
		ty.setBounds(153, 698, 175, 32);
		frame.getContentPane().add(ty);
		
	
		
		frame.revalidate();
		frame.setVisible(true);
		
		
		
	}
}
