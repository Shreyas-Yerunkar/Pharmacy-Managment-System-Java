import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.awt.event.ActionEvent;

public class Pay extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pay frame = new Pay();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void close() {
		
		WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}
	/**
	 * Create the frame.
	 */
	public Pay() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 754, 712);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CHECK OUT");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(new Color(255, 222, 173));
		lblNewLabel.setBounds(0, 0, 740, 84);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1_1 = new JLabel("PAYMENT OPTIONS");
		lblNewLabel_1_1.setOpaque(true);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_1.setBounds(0, 123, 373, 63);
		contentPane.add(lblNewLabel_1_1);
		
		JButton btnNewButton = new JButton("CARD PAYMENT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				close();
				Card c= new Card();
				c.setVisible(true);
			}
		});
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.setBounds(0, 267, 277, 63);
		contentPane.add(btnNewButton);
		
		JButton btnCod = new JButton("CASH");
		btnCod.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String filepath= "D:\\java project\\orderdata\\orderdata.txt";
				File f=new File(filepath);
				try {
					PrintWriter pw = new PrintWriter(new FileWriter(f,true));
					pw.write("Cash");
					pw.write("\n");
					pw.close();
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				File f1 = new File("D:\\java project\\receipt\\receipt.txt");
			
				try {
					FileWriter fw = new FileWriter(f1.getAbsoluteFile(),true);
					
		               fw.write("Payment Mode: Cash");
		               fw.close();
		             
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	              
			
				close();
				Delivery d= new Delivery();
				d.setVisible(true);
			}
		});
		btnCod.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnCod.setBackground(new Color(255, 222, 173));
		btnCod.setBounds(0, 403, 277, 63);
		contentPane.add(btnCod);
	}
}
