import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class Admin extends JFrame {

	private JPanel contentPane;
	private JLabel x;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin frame = new Admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
public void close() {
		
		WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}


	/**
	 * Create the frame.
	 */
	public Admin() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 757, 767);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		 x = new JLabel("");
		 x.setIcon(new ImageIcon(getClass().getResource("/Image/14.png")));
		x.setBounds(0, -29, 136, 191);
		contentPane.add(x);
		
		JLabel lblNewLabel = new JLabel("ADMIN MENU");
		lblNewLabel.setBackground(SystemColor.activeCaption);
		lblNewLabel.setOpaque(true);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setBounds(0, 0, 743, 130);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton_1 = new JButton("USER");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				close();
				Table1 j= new Table1();
				j.setVisible(true);
			}
		});
		btnNewButton_1.setBackground(new Color(255, 222, 173));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_1.setBounds(0, 322, 273, 65);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("MEDICINES");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				close();
				Table y= new Table();
				y.setVisible(true);
			}
		});
		btnNewButton_2.setBackground(new Color(255, 222, 173));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_2.setBounds(0, 428, 273, 65);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_1 = new JLabel("SELECT A OPTION");
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1.setBounds(0, 161, 369, 76);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_2_1 = new JButton("ORDERS");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				close();
				Orders b= new Orders();
				b.setVisible(true);
			}
		});
		btnNewButton_2_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_2_1.setBackground(new Color(255, 222, 173));
		btnNewButton_2_1.setBounds(0, 534, 273, 65);
		contentPane.add(btnNewButton_2_1);
	}
}
