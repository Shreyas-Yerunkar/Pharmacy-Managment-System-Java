import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JTable;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import java.awt.Font;


import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;



public class Buy1 extends JFrame  {
	
	

	private JPanel contentPane;
	public static JTable tablee;
	static DefaultTableModel Buyy;
	private static JTextField pi;
	private static JTextField pr;
	private static JTextField pn1;
	private static JTextField ex;
	private static JTextField sea;
	private JTextField qty;
	private JLabel lblCost;
	private JLabel lblTotalBill;
	private static JTextField cost;
	private static JTextField m;
	float cf=0;
	float dc=0;	
	protected DefaultTableModel DefaultTableModel;

	
	public void fn() {
		TableModel model=tablee.getModel();
		
		
		    float sum = 0;
	        for(int r = 0; r < tablee.getRowCount(); r++)
	        {
	          sum = sum + Float.parseFloat(tablee.getValueAt(r,6).toString());
	        }
	        
	       m.setText(Float.toString(sum));

	}
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Buy1 frame = new Buy1();
					//frame.setVisible(true);
		
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	
	JFrame frame= new JFrame("");
	private JLabel lblType;
	private JTextField ty;
	private JLabel lblQuantity_1;

	

	/**
	 * Create the frame.
	 */
	public Buy1() {
	
	
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 755, 843);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setFont(new Font("Tahoma", Font.BOLD, 22));
		scrollPane.setBounds(21, 62, 696, 383);
		contentPane.add(scrollPane);
		
		tablee = new JTable();
		tablee.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				

				
			
				int i=tablee.getSelectedRow();
				TableModel model=tablee.getModel();
				
		try {
			        String f = JOptionPane.showInputDialog("Enter The Quantity"); 

                    if(f == null){
                    	
                    	//JOptionPane.showMessageDialog(null,"Product Selected");
          }
                    
                    else {
			        int t=Integer.parseInt(f);
			        if(t>0&&t<40) {
			        model.setValueAt(t,i,5);
			        }
			        
			        else {
			        	JOptionPane.showMessageDialog(null, "Invalid Quantity");
			        }
                    }
			        
		} catch(NumberFormatException e1) {
						JOptionPane.showMessageDialog(null, "Invalid Quantity");
					}
	
		

				pi.setEditable(false);
				pn1.setEditable(false);
				pr.setEditable(false);
				ty.setEditable(false);
				ex.setEditable(false);
				m.setEditable(false);
				cost.setEditable(false);
				qty.setEditable(false);
				
				
				
				pi.setText(model.getValueAt(i, 0).toString());
				pn1.setText(model.getValueAt(i, 1).toString());
				pr.setText(model.getValueAt(i, 2).toString());
				ty.setText(model.getValueAt(i, 3).toString());
				ex.setText(model.getValueAt(i, 4).toString());
				qty.setText(model.getValueAt(i, 5).toString());
				
				
				String x=pr.getText();
				String y=qty.getText();
				float v=Float.parseFloat(x);
				float b=Float.parseFloat(y);
			
				float c=v*b;
				cost.setEditable(false);
				
				cost.setText(String.valueOf(c));
				
				tablee.setValueAt(c, i, 6);
				

				boolean a=tablee.isEditing();
				
			
				if(a==false) {
					
					JOptionPane.showMessageDialog(null,"Product Selected");
				
				}
			
			
			}
		});
		scrollPane.setViewportView(tablee);
		tablee.setBackground(Color.white);
		tablee.setForeground(Color.black);
		tablee.setSelectionBackground(Color.MAGENTA);
		tablee.setGridColor(Color.red);
		tablee.setSelectionForeground(Color.white);
		tablee.setFont(new Font("Tahoma",Font.PLAIN,17));
		tablee.setRowHeight(30);
		tablee.setAutoCreateRowSorter(true);
		tablee.setBackground(SystemColor.text);
		
		
		tablee.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Product Id", "Product Name", "Price","Type", "Expiry Date", "Quantity", "Price"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false,false,true,false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		JLabel lblNewLabel = new JLabel("Product ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel.setBounds(10, 466, 152, 42);
		contentPane.add(lblNewLabel);
		
		JLabel lblProductName = new JLabel("Product Name");
		lblProductName.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblProductName.setBounds(10, 518, 152, 42);
		contentPane.add(lblProductName);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblPrice.setBounds(10, 581, 152, 42);
		contentPane.add(lblPrice);
		
		JLabel lblExpiryDate = new JLabel("Expiry Date");
		lblExpiryDate.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblExpiryDate.setBounds(10, 640, 152, 42);
		contentPane.add(lblExpiryDate);
		
		pi = new JTextField();
		pi.setFont(new Font("Tahoma", Font.BOLD, 19));
		pi.setBounds(172, 473, 175, 32);
		contentPane.add(pi);
		pi.setColumns(10);
		
		pn1 = new JTextField();
		pn1.setFont(new Font("Tahoma", Font.BOLD, 19));
		pn1.setColumns(10);
		pn1.setBounds(172, 524, 175, 32);
		contentPane.add(pn1);
		
		pr = new JTextField();
		pr.setFont(new Font("Tahoma", Font.BOLD, 19));
		pr.setColumns(10);
		pr.setBounds(172, 587, 175, 32);
		contentPane.add(pr);
		
		ex = new JTextField();
		ex.setFont(new Font("Tahoma", Font.BOLD, 19));
		ex.setColumns(10);
		ex.setBounds(172, 646, 175, 32);
		contentPane.add(ex);
		
		qty = new JTextField();
		qty.setFont(new Font("Tahoma", Font.BOLD, 19));
		qty.setColumns(10);
		qty.setBounds(542, 524, 175, 32);
		contentPane.add(qty);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblQuantity.setBounds(241, 581, 152, 42);
		contentPane.add(lblQuantity);
		
		
		
		sea = new JTextField();
		sea.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				

				DefaultTableModel model = (DefaultTableModel)tablee.getModel();
				String search =sea.getText();
				TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(model);
				tablee.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
		
			}
		});
		sea.setFont(new Font("Tahoma", Font.BOLD, 19));
		sea.setColumns(10);
		sea.setBounds(556, 10, 175, 32);
		contentPane.add(sea);
		
		JLabel lblSearch = new JLabel("Search");
		lblSearch.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblSearch.setBounds(406, 10, 152, 42);
		contentPane.add(lblSearch);
		
		lblCost = new JLabel("Cost");
		lblCost.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblCost.setBounds(377, 581, 152, 42);
		contentPane.add(lblCost);
		
		lblTotalBill = new JLabel("Total Bill");
		lblTotalBill.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblTotalBill.setBounds(377, 640, 152, 42);
		contentPane.add(lblTotalBill);
		
		cost = new JTextField();
		cost.setFont(new Font("Tahoma", Font.BOLD, 19));
		cost.setColumns(10);
		cost.setBounds(542, 587, 175, 32);
		contentPane.add(cost);
		
		m = new JTextField();
		m.setFont(new Font("Tahoma", Font.BOLD, 19));
		m.setColumns(10);
		m.setBounds(542, 646, 175, 32);
		contentPane.add(m);
		
		
		
		JButton btnNewButton = new JButton("Total Amount");
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ch=JOptionPane.showConfirmDialog(null, "Get Total Amount","Total Amount",JOptionPane.YES_NO_OPTION);
				if(ch==0) {
					
			fn();

			}
				}
			
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.setBounds(49, 737, 202, 45);
		contentPane.add(btnNewButton);
		
		JButton btnModifyOrder = new JButton("Delete");
		btnModifyOrder.setBackground(new Color(255, 222, 173));
		btnModifyOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel model= (DefaultTableModel) tablee.getModel();
				
				if(m.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Please Press the Total Amount Button First For Deletion");
					
					
				}
				
				else {
				
				int ch=JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this item","Delete",JOptionPane.YES_NO_OPTION);
				
				if(ch==0) {
					
					String o=cost.getText();

					float y=Float.parseFloat(o);
					
					String h=m.getText();
					float dc=Float.parseFloat(h);
					
					for(int d=0;d<tablee.getSelectedRowCount();d++) { 
						dc=dc-y;
					}
						
					m.setText(String.valueOf(dc));
		
					
				if(tablee.getSelectedRowCount()==1) {
					
					model.removeRow(tablee.getSelectedRow());

			
					}

				} 
				
				
				else {
					
					if(tablee.getRowCount()==0) {
						JOptionPane.showMessageDialog(null, "Delete Not Possible");
						
					}else {
						
						JOptionPane.showMessageDialog(null, "Multiple Selection Error");
					}
				}
				
			}
			}
		});
		btnModifyOrder.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnModifyOrder.setBounds(516, 737, 176, 45);
		contentPane.add(btnModifyOrder);
		
		JButton btnBack = new JButton("Reselect");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				User d = new User();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 19));
		btnBack.setBounds(0, 0, 176, 42);
		contentPane.add(btnBack);
		
		JButton btnNewButton_1 = new JButton("Proceed");
		btnNewButton_1.setBackground(new Color(255, 222, 173));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(m.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Please Press the Total Amount Button to Proceed");
					
					
				}
				
	else {
		Pay t=new Pay();
		t.setVisible(true);
				
				
				String msg=m.getText();
				
					
				
				String filepath= "D:\\java project\\orderdata\\orderdata.txt";
				File f=new File(filepath);
				try {
					PrintWriter pw = new PrintWriter(new FileWriter(f,true));
					pw.write("\n");
					
					for(int x=0;x<tablee.getRowCount();x++) {
					for(int y=0;y<tablee.getColumnCount();y++) {
					
						pw.write(tablee.getValueAt(x, y).toString()+" \t");
						
				
					}
					pw.write("\n");
					}
					
					pw.write("Total:"+msg);
					pw.write("\n");
					pw.close();
				
					
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		
				try {
					File f1 = new File("D:\\java project\\receipt\\receipt.txt");
					FileWriter fw = new FileWriter(f1.getAbsoluteFile(),true);
		               fw.write("CUSTOMER RECEIPT");
		               fw.write("\n\n");
		               fw.write("ProductID\t ProductName\t Price\t Type\t ExpiryDate\t Quantity\t Price ");
		               fw.write("\n");
					for(int x=0;x<tablee.getRowCount();x++) {
					for(int y=0;y<tablee.getColumnCount();y++) {
					
						fw.write(tablee.getValueAt(x, y).toString()+"\t");
						
				
					}
					fw.write("\n");
					}
					fw.write("\n");
					fw.write("Total:"+msg);
					fw.write("\n");
			
					fw.close();
					
					
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
	}
			}
		});
		btnNewButton_1.setBounds(284, 737, 176, 45);
		contentPane.add(btnNewButton_1);
		
		lblType = new JLabel("Type");
		lblType.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblType.setBounds(377, 466, 152, 42);
		contentPane.add(lblType);
		
		ty = new JTextField();
		ty.setFont(new Font("Tahoma", Font.BOLD, 19));
		ty.setColumns(10);
		ty.setBounds(542, 472, 175, 32);
		contentPane.add(ty);
		
		lblQuantity_1 = new JLabel("Quantity");
		lblQuantity_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblQuantity_1.setBounds(377, 518, 152, 42);
		contentPane.add(lblQuantity_1);
		
		
	}
}

