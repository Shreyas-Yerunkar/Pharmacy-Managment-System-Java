import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import java.awt.SystemColor;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Re extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Re frame = new Re();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Re() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 754, 737);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(95, 138, 559, 317);
		contentPane.add(textArea);
		
		JButton btnNewButton = new JButton("Receipt");
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String filepath= "D:\\java project\\receipt\\receipt.txt";
				File f=new File(filepath);
				
				try {
					FileReader r=new FileReader(filepath);
					BufferedReader b= new BufferedReader(r);
					textArea.read(b, null);
					b.close();
					textArea.requestFocus();
					
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				try {
					boolean c=textArea.print();
					if(c) {
						JOptionPane.showMessageDialog(null, "Done","Receipt",JOptionPane.INFORMATION_MESSAGE);
						
					}
					else {
						JOptionPane.showMessageDialog(null, "Printing","Printer",JOptionPane.ERROR_MESSAGE);
					}
				} catch (PrinterException e2) {
					JOptionPane.showMessageDialog(null, e2);
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				JOptionPane.showMessageDialog(null, "THANK YOU FOR SHOPPING WITH US");
				
				
				PrintWriter writer;
				try {
					writer = new PrintWriter(f);
					writer.print("");
					writer.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				btnNewButton.setEnabled(false);	
			}
			
			
			
		});
		btnNewButton.setBounds(259, 519, 222, 49);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("CUSTOMER RECEIPT");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(new Color(255, 222, 173));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel.setBounds(0, 35, 292, 55);
		contentPane.add(lblNewLabel);
	}
}
