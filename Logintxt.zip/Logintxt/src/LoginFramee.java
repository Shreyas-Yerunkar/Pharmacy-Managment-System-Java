import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class LoginFramee extends JFrame {

	private JPanel contentPane;
	private JLabel w;

	File f= new File("D:\\java project\\logindata");
	int ln;
	String username,password;
	private JTextField user;
	private JPasswordField pass;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFramee frame = new LoginFramee();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	void createFolder() {
		if(!f.exists()) {
			f.mkdirs();
			
		}
	}
	
	void readFile() {
		
		try {
			FileReader fr=new FileReader(f+"\\logins.txt");
			System.out.println("File exsists");
			FileReader fr1=new FileReader(f+"\\logind.txt");
			System.out.println("File exsists");

		} catch (FileNotFoundException e) {
			
			try {
				FileWriter fw= new FileWriter(f+"\\logins.txt");
				System.out.println("File created");
				FileWriter fw1= new FileWriter(f+"\\logind.txt");
				System.out.println("File created");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		
	}
	

	void countLines() {
		
		try {
			ln=1;
			RandomAccessFile raf= new RandomAccessFile(f+"\\logins.txt","rw");
			for(int i=0;raf.readLine()!=null;i++) {
				ln++;
				
			}
			
			System.out.println("Number of lines "+ln);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	void logic(String usr,String pas) {
		
		try {
			RandomAccessFile raf = new RandomAccessFile(f+"\\logins.txt","rw");
			raf.readLine();
			for(int i=0;i<ln;i+=7) {
				String forUser = raf.readLine().substring(9);
				String forPass = raf.readLine().substring(9);
				if(usr.equals(forUser)& pas.equals(forPass)) {
				JOptionPane.showMessageDialog(null, "Password Matched");
				close();
				User v= new User();
				//v.setVisible(true);
				break;
					
				}else if(i==(ln-7)) {
					
					JOptionPane.showMessageDialog(null, " Username or Password Not Matched");
				}	
				for(int k=1;k<=5;k++) {
					raf.readLine();
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.print("Error");
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}
	
	
	public void close() {
		
		WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}
	
	
	
	/**
	 * Create the frame.
	 */
	public LoginFramee() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 734, 752);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOGIN");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(new Color(255, 218, 185));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setBounds(123, 0, 597, 130);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton(" REGISTER");
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				close();
				Register r= new Register();
				r.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.setBounds(36, 556, 199, 64);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton(" LOGIN");
		btnNewButton_1.setBackground(new Color(255, 222, 173));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				createFolder();
				readFile();
				countLines();
				logic(user.getText(),pass.getText());
			}
		});
		btnNewButton_1.setBounds(277, 556, 176, 64);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("TRACK ORDER");
		btnNewButton_2.setBackground(new Color(255, 222, 173));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Userr d= new Userr();
				d.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(488, 556, 222, 64);
		contentPane.add(btnNewButton_2);
		
		 w = new JLabel("");
		 w.setBackground(new Color(255, 222, 173));
		 w.setOpaque(true);
		w.setIcon(new ImageIcon(getClass().getResource("/Image/54.png")));
		w.setBounds(0, 0, 141, 130);
		contentPane.add(w);
		
		JLabel lblNewLabel_1_1 = new JLabel("USERNAME");
		lblNewLabel_1_1.setOpaque(true);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_1.setBounds(0, 190, 273, 65);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD");
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1.setBounds(0, 321, 273, 65);
		contentPane.add(lblNewLabel_1);
		
		user = new JTextField();
		user.setFont(new Font("Tahoma", Font.BOLD, 19));
		user.setColumns(10);
		user.setBackground(Color.WHITE);
		user.setBounds(346, 202, 290, 43);
		contentPane.add(user);
		
		pass = new JPasswordField();
		pass.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {
					
				
				createFolder();
				readFile();
				countLines();
				logic(user.getText(),pass.getText());
			} 
				}
		});
		pass.setBounds(346, 321, 290, 43);
		contentPane.add(pass);
	}
}
