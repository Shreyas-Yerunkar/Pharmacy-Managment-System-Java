
import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.text.JTextComponent;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.awt.event.ActionEvent;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class Table1 extends JTable {
	public Table1() {
		in();
	}
	private JFrame frame;
	private JTextField sea;
	private static JTextField u;
	private static JTextField n;
	private static JTextField m;
	private static JTextField p;
	private static JTextField s;
	
	


	public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Table1 frame = new Table1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		}
		
		
	
		
		private void in() {
		
		JTable table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				int i=table.getSelectedRow();
				TableModel model=table.getModel();
				
				u.setEditable(false);
				p.setEditable(false);
				n.setEditable(false);
				s.setEditable(false);
				m.setEditable(false);
			
				
			
				
				u.setText(model.getValueAt(i, 0).toString());
				p.setText(model.getValueAt(i, 1).toString());
				n.setText(model.getValueAt(i, 2).toString());
				s.setText(model.getValueAt(i, 3).toString());
				m.setText(model.getValueAt(i, 4).toString());
				
				boolean a=table.isEditing();
				
				if(a==false) {
					
					JOptionPane.showMessageDialog(null,"User Selected");
				}
			
			
			}
		});
		
		DefaultTableModel model=new DefaultTableModel();
		
		JFrame frame= new JFrame("");
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.setBounds(100,100,756,773);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
	
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"UserName", "Password", "Name", "Email", "Mobile"
			}
		));
		
		table.setBackground(Color.white);
		table.setForeground(Color.black);
		table.setSelectionBackground(Color.MAGENTA);
		table.setGridColor(Color.red);
		table.setSelectionForeground(Color.white);
		table.setFont(new Font("Tahoma",Font.PLAIN,17));
		table.setRowHeight(30);
		table.setAutoCreateRowSorter(true);
		
		JScrollPane pane = new JScrollPane(table);
		pane.setForeground(Color.red);
		pane.setBackground(Color.white);
		pane.setBounds(10,78,722,333);
		frame.getContentPane().add(pane);
		Object[] row = new Object[4];
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ch=JOptionPane.showConfirmDialog(null, "Do you wish to add a new user","Add User",JOptionPane.YES_NO_OPTION);
				if(ch==0) {
			Register n = new Register();
			n.setVisible(true);
			}
				}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 27));
		btnNewButton.setBounds(153, 667, 169, 47);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_3 = new JButton("Database");
		btnNewButton_3.setBackground(new Color(255, 222, 173));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String filepath = "D:\\java project\\logindata\\logind.txt";
	            File file=new File(filepath);
	            try {
	                BufferedReader br = new BufferedReader(new FileReader(file));
	                String firstLine = br.readLine().trim();
	                String[] columnsName = firstLine.split("\n");
	                
	                DefaultTableModel model = (DefaultTableModel)table.getModel();
	                model.setColumnIdentifiers(columnsName);
	            	Object [] columns = { "UserName","Password","Name","Email","Mobile"};
	            	model.setColumnIdentifiers(columns);
	            	table.setModel(model);
			
	                Object[] tableLines = br.lines().toArray();

	        	
	           
	                for(int i = 0; i < tableLines.length; i++)
	                {
	                    String line = tableLines[i].toString().trim();
	                    String[] dataRow = line.split("\t");
	                    model.addRow(dataRow);
	                }
	                

	            } catch (Exception e1) {
	 
	          }

	            }
	        });
	          

	        
		btnNewButton_3.setBounds(450, 668, 169, 47);
		frame.getContentPane().add(btnNewButton_3);
		
		JLabel lblSearch = new JLabel("Search");
		lblSearch.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblSearch.setBounds(417, 14, 109, 42);
		frame.getContentPane().add(lblSearch);
		
		sea = new JTextField();
		sea.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				

				DefaultTableModel model = (DefaultTableModel)table.getModel();
				String search =sea.getText();
				TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(model);
				table.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
		
			}
		});
		sea.setFont(new Font("Tahoma", Font.BOLD, 19));
		sea.setColumns(10);
		sea.setBounds(536, 20, 175, 32);
		frame.getContentPane().add(sea);
		
		JLabel lblUsername = new JLabel("UserName");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblUsername.setBounds(10, 454, 152, 42);
		frame.getContentPane().add(lblUsername);
		
		u = new JTextField();
		u.setFont(new Font("Tahoma", Font.BOLD, 19));
		u.setColumns(10);
		u.setBounds(153, 464, 175, 32);
		frame.getContentPane().add(u);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblName.setBounds(10, 524, 152, 42);
		frame.getContentPane().add(lblName);
		
		JLabel lblMobile = new JLabel("Mobile");
		lblMobile.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblMobile.setBounds(10, 593, 152, 42);
		frame.getContentPane().add(lblMobile);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblPassword.setBounds(417, 454, 152, 42);
		frame.getContentPane().add(lblPassword);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblEmail.setBounds(417, 524, 152, 42);
		frame.getContentPane().add(lblEmail);
		
		n = new JTextField();
		n.setFont(new Font("Tahoma", Font.BOLD, 19));
		n.setColumns(10);
		n.setBounds(153, 540, 175, 32);
		frame.getContentPane().add(n);
		
		m = new JTextField();
		m.setFont(new Font("Tahoma", Font.BOLD, 19));
		m.setColumns(10);
		m.setBounds(153, 609, 175, 32);
		frame.getContentPane().add(m);
		
		p = new JTextField();
		p.setFont(new Font("Tahoma", Font.BOLD, 19));
		p.setColumns(10);
		p.setBounds(536, 464, 175, 32);
		frame.getContentPane().add(p);
		
		s = new JTextField();
		s.setFont(new Font("Tahoma", Font.BOLD, 19));
		s.setColumns(10);
		s.setBounds(536, 540, 175, 32);
		frame.getContentPane().add(s);
		
	
		
		frame.revalidate();
		frame.setVisible(true);
		
		
	}
}
