import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.awt.event.ActionEvent;

public class Delivery extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Delivery frame = new Delivery();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
public void close() {
		
		WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}
	/**
	 * Create the frame.
	 */
	public Delivery() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 759, 769);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDeliveryOptions = new JLabel("DELIVERY OPTIONS");
		lblDeliveryOptions.setOpaque(true);
		lblDeliveryOptions.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblDeliveryOptions.setBackground(new Color(255, 222, 173));
		lblDeliveryOptions.setBounds(0, 123, 369, 76);
		contentPane.add(lblDeliveryOptions);
		
		JLabel lblNewLabel = new JLabel("CHECK OUT");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setBackground(new Color(255, 222, 173));
		lblNewLabel.setBounds(0, 0, 745, 84);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("HOME DELIVERY");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String a;
				a = JOptionPane.showInputDialog("Address");

				if(a.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Please Enter the Address");
					
				}
				
				else {
					
				
				String filepath= "D:\\java project\\orderdata\\orderdata.txt";
				File f=new File(filepath);
				try {
					PrintWriter pw = new PrintWriter(new FileWriter(f,true));
					pw.write("Home Delivery");
					pw.write("\n");
					pw.write("Address:"+a);
					pw.close();
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				 
				File f1 = new File("D:\\java project\\receipt\\receipt.txt");
				
				try {
					FileWriter fw = new FileWriter(f1.getAbsoluteFile(),true);
						fw.write("\n");
		               fw.write("Delivery Mode: Home Delivery");
		               fw.write("\n");
		               fw.write("Address:"+a);
		               fw.close();
		             
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				close();
				L c= new L();
				c.setVisible(true);
			}
			}
		});
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.setBounds(0, 278, 246, 62);
		contentPane.add(btnNewButton);
		
		JButton btnPickUp = new JButton("PICK UP");
		btnPickUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String filepath= "D:\\java project\\orderdata\\orderdata.txt";
				File f=new File(filepath);
				try {
					PrintWriter pw = new PrintWriter(new FileWriter(f,true));
					pw.write("Pick Up");
					pw.close();
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				File f1 = new File("D:\\java project\\receipt\\receipt.txt");
				
				try {
					FileWriter fw = new FileWriter(f1.getAbsoluteFile(),true);
						fw.write("\n");
		               fw.write("Delivery Mode: Pick Up");
		               fw.close();
		             
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				close();
				L c= new L();
				c.setVisible(true);
				
			}
		});
		btnPickUp.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnPickUp.setBackground(new Color(255, 222, 173));
		btnPickUp.setBounds(0, 411, 246, 62);
		contentPane.add(btnPickUp);
	}
}
