import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Admin1 extends JFrame {
	
	private JPanel contentPane;
	private JLabel x;
	private JPasswordField w;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin1 frame = new Admin1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
public void close() {
		
		WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}



	/**
	 * Create the frame.
	 */
public Admin1() {
	setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	setBounds(100, 100, 757, 733);
	contentPane = new JPanel();
	contentPane.setBackground(SystemColor.activeCaption);
	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	setContentPane(contentPane);
	contentPane.setLayout(null);
	
	 x = new JLabel("");
	 x.setIcon(new ImageIcon(getClass().getResource("/Image/14.png")));
	x.setBounds(0, -29, 136, 191);
	contentPane.add(x);
	
	JLabel lblNewLabel = new JLabel("ADMIN MENU");
	lblNewLabel.setBackground(new Color(255, 222, 173));
	lblNewLabel.setOpaque(true);
	lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
	lblNewLabel.setBounds(0, 0, 743, 130);
	contentPane.add(lblNewLabel);
	
	JButton btnNewButton = new JButton("LOGIN-IN");
	btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			String p="shreyas123";
			String d=w.getText();
			
			if(w.getText().equals(p)) {
				
				close();
				Admin b= new Admin();
				b.setVisible(true);
			}
			
			else {
				
				JOptionPane.showMessageDialog(null,"Password Not Match");
			}
		}
	});
	btnNewButton.setBackground(new Color(255, 222, 173));
	btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
	btnNewButton.setBounds(256, 512, 239, 53);
	contentPane.add(btnNewButton);
	
	JLabel lblNewLabel_1 = new JLabel("ADMIN PASSWORD");
	lblNewLabel_1.setOpaque(true);
	lblNewLabel_1.setBackground(new Color(255, 222, 173));
	lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 24));
	lblNewLabel_1.setBounds(0, 310, 273, 65);
	contentPane.add(lblNewLabel_1);
	
	w = new JPasswordField();
	w.addKeyListener(new KeyAdapter() {
		@Override
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode()==KeyEvent.VK_ENTER) {
				String p="shreyas123";
				String d=w.getText();
				
				if(w.getText().equals(p)) {
					
					close();
					Admin b= new Admin();
					b.setVisible(true);
				}
				
				else {
					
					JOptionPane.showMessageDialog(null,"Password Not Match");
				}
				
			}
		}
	});
	w.setFont(new Font("Arial",Font.BOLD,19));
	w.setBounds(315, 320, 328, 53);
	contentPane.add(w);
	
	JLabel lblNewLabel_1_1 = new JLabel("ENTER THE PASSWORD");
	lblNewLabel_1_1.setOpaque(true);
	lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
	lblNewLabel_1_1.setBackground(new Color(255, 222, 173));
	lblNewLabel_1_1.setBounds(0, 157, 369, 76);
	contentPane.add(lblNewLabel_1_1);
}	
}