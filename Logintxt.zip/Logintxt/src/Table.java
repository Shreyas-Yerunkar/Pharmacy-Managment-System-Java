import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.awt.event.ActionEvent;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class Table extends JFrame  {
	public Table() {
		ie();
	}
	private static JTextField sea;
	private JFrame frame;
	private JTextField pi;
	private JTextField pr;
	private JTextField pn1;
	private JTextField ex;
	private JTextField ty;

public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Table frame = new Table();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		}
		

private void ie() {
	
		JTable table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				int i=table.getSelectedRow();
				TableModel model=table.getModel();
				
				pi.setEditable(false);
				pn1.setEditable(false);
				pr.setEditable(false);
				ex.setEditable(false);
				ty.setEditable(false);
				
				pi.setText(model.getValueAt(i, 0).toString());
				pr.setText(model.getValueAt(i, 1).toString());
				pn1.setText(model.getValueAt(i, 2).toString());
				ty.setText(model.getValueAt(i, 3).toString());
				ex.setText(model.getValueAt(i, 4).toString());
				
			}
		});
	
	
			
			
			
		

		DefaultTableModel model=new DefaultTableModel();
		
		JFrame frame= new JFrame("");
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.setBounds(100,100,776,858);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		

		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"Product Id","Product Name","Price","Type","Expiry Date"
			}
		));
		table.setModel(model);
		table.setBackground(Color.white);
		table.setForeground(Color.black);
		table.setSelectionBackground(Color.MAGENTA);
		table.setGridColor(Color.red);
		table.setSelectionForeground(Color.white);
		table.setFont(new Font("Tahoma",Font.PLAIN,17));
		table.setRowHeight(30);
		table.setAutoCreateRowSorter(true);
		
		JScrollPane pane = new JScrollPane(table);
		pane.setVisible(true);
		
		pane.setForeground(new Color(255, 165, 0));
		pane.setBackground(Color.white);
		pane.setBounds(10,79,722,436);
		frame.getContentPane().add(pane);
		Object[] row = new Object[5];
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AddRec f= new AddRec();
				f.setVisible(true);
				}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.setBounds(21, 767, 176, 45);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("DELETE");
		btnNewButton_1.setBackground(new Color(255, 222, 173));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				int i =table.getSelectedRow();
				
				if(i>=0) {
					
					
					model.removeRow(i);
				
					
					
				}else {
					
					JOptionPane.showMessageDialog(frame, "Delete Not Possible");
					
				}
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_1.setBounds(202, 767, 176, 45);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("SAVE");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_2.setBackground(new Color(255, 222, 173));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {		        

	                
	               try{
	               
	               
	            File file = new File("D:\\java project\\medicinedata\\medicinedata.txt");
	           FileWriter fw = new FileWriter(file.getAbsoluteFile());
	           BufferedWriter bw = new BufferedWriter(fw);
	           bw.write("\n");
	           
	           for(int i = 0; i < model.getRowCount(); i++)
	           {
	               for (int j = 0; j < model.getColumnCount(); j++)
	               {
	                  
	            	   bw.write(table.getModel().getValueAt(i, j)+" \t");
	            	 
	               }
	              
	               bw.write("\n");
	       
	           }
	                
	         
	           bw.close();
	           fw.close();               
	           }
	           catch (Exception ex)
	           {
	               ex.printStackTrace();
	           }
	           }
	       });  
				
				
	
		btnNewButton_2.setBounds(388, 767, 176, 45);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("DATABASE");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_3.setBackground(new Color(255, 222, 173));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
	            String filepath = "D:\\java project\\medicinedata\\medicinedata.txt";
	            File file=new File(filepath);
	            try {
	                BufferedReader br = new BufferedReader(new FileReader(file));
	                String firstLine = br.readLine().trim();
	                String[] columnsName = firstLine.split("\n");
	                
	                DefaultTableModel model = (DefaultTableModel)table.getModel();
	                model.setColumnIdentifiers(columnsName);
	            	Object [] columns = { "Product Id","Product Name","Price","Type","Expiry Date"};
	            	model.setColumnIdentifiers(columns);
	            	table.setModel(model);
			
	                Object[] tableLines = br.lines().toArray();

				
	        	
	           
	                for(int i = 0; i < tableLines.length; i++)
	                {
	                    String line = tableLines[i].toString().trim();
	                    String[] dataRow = line.split("\t");
	                    model.addRow(dataRow);
	                }
	                

	            } catch (Exception e1) {
	 
	          }

	            }
	        });
	          

	        
		btnNewButton_3.setBounds(576, 767, 176, 45);
		frame.getContentPane().add(btnNewButton_3);
		
		sea = new JTextField();
		sea.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				

				DefaultTableModel model = (DefaultTableModel)table.getModel();
				String search =sea.getText();
				TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(model);
				table.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
		
				
			}
		});
		sea.setBackground(new Color(255, 255, 255));
		sea.setFont(new Font("Arial",Font.BOLD,19));
	
		
		sea.setBounds(526, 20, 184, 35);
		frame.getContentPane().add(sea);
		sea.setColumns(10);
		
		JLabel lblProductId = new JLabel("Product Id");
		lblProductId.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblProductId.setBounds(10, 543, 152, 42);
		frame.getContentPane().add(lblProductId);
		
		pi = new JTextField();
		pi.setFont(new Font("Tahoma", Font.BOLD, 19));
		pi.setColumns(10);
		pi.setBounds(142, 549, 175, 32);
		frame.getContentPane().add(pi);
		
		JLabel lblProductId_1 = new JLabel("Price");
		lblProductId_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblProductId_1.setBounds(354, 543, 152, 42);
		frame.getContentPane().add(lblProductId_1);
		
		JLabel lblProductId_2 = new JLabel(" Product Name");
		lblProductId_2.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblProductId_2.setBounds(0, 612, 152, 42);
		frame.getContentPane().add(lblProductId_2);
		
		JLabel lblProductId_3 = new JLabel("Type");
		lblProductId_3.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblProductId_3.setBounds(354, 612, 152, 42);
		frame.getContentPane().add(lblProductId_3);
		
		pr = new JTextField();
		pr.setFont(new Font("Tahoma", Font.BOLD, 19));
		pr.setColumns(10);
		pr.setBounds(142, 618, 175, 32);
		frame.getContentPane().add(pr);
		
		pn1 = new JTextField();
		pn1.setFont(new Font("Tahoma", Font.BOLD, 19));
		pn1.setColumns(10);
		pn1.setBounds(526, 549, 175, 32);
		frame.getContentPane().add(pn1);
		
		ex = new JTextField();
		ex.setFont(new Font("Tahoma", Font.BOLD, 19));
		ex.setColumns(10);
		ex.setBounds(142, 688, 175, 32);
		frame.getContentPane().add(ex);
		
		JLabel lblProductId_3_1 = new JLabel("Expiry Date");
		lblProductId_3_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblProductId_3_1.setBounds(10, 682, 152, 42);
		frame.getContentPane().add(lblProductId_3_1);
		
		ty = new JTextField();
		ty.setFont(new Font("Tahoma", Font.BOLD, 19));
		ty.setColumns(10);
		ty.setBounds(526, 618, 175, 32);
		frame.getContentPane().add(ty);
		
		JLabel lblSearch = new JLabel("Search");
		lblSearch.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblSearch.setBounds(407, 15, 109, 42);
		frame.getContentPane().add(lblSearch);
		
	
		
		frame.revalidate();
		frame.setVisible(true);
		
		
	}
}
