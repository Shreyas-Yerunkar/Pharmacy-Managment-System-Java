import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;



import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.awt.event.ActionEvent;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class Orders extends JFrame  {
	
	public  Orders() {
		
		a();
	}
	
	
	private JFrame frame;
	protected DefaultTableModel DefaultTableModel;
	private JTextField sea;

public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 Orders frame = new  Orders();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		}
		

private void a() {
	
	
		JTable tables = new JTable();

	
		DefaultTableModel model=new DefaultTableModel();
		
		JFrame frame= new JFrame("");
		frame.getContentPane().setBackground(SystemColor.activeCaption);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.setBounds(100,100,769,812);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		

		tables.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Product Id", "Product Name", "Price", "Type","Expiry Date", "Quantity", "Price"
			}
		));
		
		tables.setBackground(Color.white);
		tables.setForeground(Color.black);
		tables.setSelectionBackground(Color.red);
		tables.setGridColor(Color.red);
		tables.setSelectionForeground(Color.white);
		tables.setFont(new Font("Tahoma",Font.PLAIN,17));
		tables.setRowHeight(30);
		tables.setAutoCreateRowSorter(true);
		
		JScrollPane pane = new JScrollPane(tables);
		pane.setVisible(true);
		
		pane.setForeground(Color.red);
		pane.setBackground(Color.white);
		pane.setBounds(10,77,722,544);
		frame.getContentPane().add(pane);
		Object[] row = new Object[5];
		
		JButton btnNewButton_3 = new JButton("View Orders");
		btnNewButton_3.setBackground(new Color(255, 222, 173));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
	            String filepath = "D:\\java project\\orderdata\\orderdata.txt";
	            File file=new File(filepath);
	            try {
	                BufferedReader br = new BufferedReader(new FileReader(file));
	                String firstLine = br.readLine().trim();
	                String[] columnsName = firstLine.split("\n");
	                
	                DefaultTableModel model = (DefaultTableModel)tables.getModel();
	                model.setColumnIdentifiers(columnsName);
	            	Object [] columns = { "Product Id","Product Name","Price","Type","Expiry Date","Quantity","Price"};
	            	model.setColumnIdentifiers(columns);
	            	tables.setModel(model);
			
	                Object[] tableLines = br.lines().toArray();

	           
	                for(int i = 0; i < tableLines.length; i++)
	                {
	                    String line = tableLines[i].toString().trim();
	                    String[] dataRow = line.split("\t");
	                    model.addRow(dataRow);
	                }
	                

	            } catch (Exception e1) {
	 
	          }
	            	
	            btnNewButton_3.setEnabled(false);
	            
	            
	            }
	        });
	          

	        
		btnNewButton_3.setBounds(238, 671, 248, 46);
		frame.getContentPane().add(btnNewButton_3);
		
		JLabel lblSearch = new JLabel("Search");
		lblSearch.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblSearch.setBounds(430, 15, 109, 42);
		frame.getContentPane().add(lblSearch);
		
		sea = new JTextField();
		sea.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				DefaultTableModel model = (DefaultTableModel)tables.getModel();
				String search =sea.getText();
				TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(model);
				tables.setRowSorter(tr);
				tr.setRowFilter(RowFilter.regexFilter(search));
			}
		});
		sea.setFont(new Font("Tahoma", Font.BOLD, 19));
		sea.setColumns(10);
		sea.setBounds(531, 21, 175, 32);
		frame.getContentPane().add(sea);
		
	
		
		frame.revalidate();
		frame.setVisible(true);
		
		
	}
}
