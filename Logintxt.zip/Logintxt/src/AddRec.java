import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class AddRec extends JFrame {

	private JPanel contentPane;
	
	File f= new File("D:\\java project\\medicinedata");
	int ln;
	
	String id,name,price,exp;
	
	private JTextField pid;
	private JTextField pn;
	private JTextField p;
	private JTextField ew;
	private JTextField ty;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddRec frame = new AddRec();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	void createFolder() {
		if(!f.exists()) {
			f.mkdirs();
			
		}
	}
	
	
	void readFile() {
		
		try {
			FileReader fr=new FileReader(f+"\\medicinedata.txt");
			System.out.println("File exsists");
		} catch (FileNotFoundException e) {
			
			try {
				FileWriter fw= new FileWriter(f+"\\medicinedata.txt");
				System.out.println("File created");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		
	}
	
	
	
void countLines() {
		
		try {
			ln=1;
			RandomAccessFile raf= new RandomAccessFile(f+"\\medicinedata.txt","rw");
			for(int i=0;raf.readLine()!=null;i++) {
				ln++;
				
			}
			
			System.out.println("Number of lines "+ln);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

void addData(String idn,String name1,String price1,String t,String exp1) {
	
	try {
		RandomAccessFile raf= new RandomAccessFile(f+"\\medicinedata.txt","rw");
		for(int i=0;i<ln;i++) {
			raf.readLine();
		}
		
		raf.writeBytes("\r\n");
	
		
		
		raf.writeBytes(idn+"\t");
		raf.writeBytes(name1+"\t");
		raf.writeBytes(price1+"\t");	
		raf.writeBytes(t+"\t");
		raf.writeBytes(exp1+"\t");	

		
		
	} catch (IOException e) {
	
		e.printStackTrace();
	}
}
	
	
	
	
public void close() {
	
	WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
	Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
}

	
	/**
	 * Create the frame.
	 */
	public AddRec() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 789);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				int ch=JOptionPane.showConfirmDialog(null, "Are you sure the entered details are correct","Add Medicine",JOptionPane.YES_NO_OPTION);
				if(ch==0) {
				float a =Float.parseFloat(p.getText());
				close();
				createFolder();
				readFile();
				countLines();
				addData(pid.getText(),pn.getText(),p.getText(),ty.getText(),ew.getText());
			}
				}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.setBounds(265, 684, 189, 58);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setBounds(29, 374, 45, 13);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_1_1 = new JLabel("PRODUCT ID");
		lblNewLabel_1_1.setOpaque(true);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_1.setBounds(0, 162, 273, 65);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("PRODUCT NAME");
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1.setBounds(0, 263, 273, 65);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("PRICE");
		lblNewLabel_1_2.setOpaque(true);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_2.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_2.setBounds(0, 362, 273, 65);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("EXPIRY DATE");
		lblNewLabel_1_3.setOpaque(true);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_3.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_3.setBounds(0, 568, 273, 65);
		contentPane.add(lblNewLabel_1_3);
		
		pid = new JTextField();
		pid.setFont(new Font("Tahoma", Font.BOLD, 19));
		pid.setColumns(10);
		pid.setBackground(Color.WHITE);
		pid.setBounds(350, 172, 290, 43);
		contentPane.add(pid);
		
		pn = new JTextField();
		pn.setFont(new Font("Tahoma", Font.BOLD, 19));
		pn.setColumns(10);
		pn.setBackground(Color.WHITE);
		pn.setBounds(350, 274, 290, 43);
		contentPane.add(pn);
		
		p = new JTextField();
		p.setFont(new Font("Tahoma", Font.BOLD, 19));
		p.setColumns(10);
		p.setBackground(Color.WHITE);
		p.setBounds(350, 374, 290, 43);
		contentPane.add(p);
		
		ew = new JTextField();
		ew.setFont(new Font("Tahoma", Font.BOLD, 19));
		ew.setColumns(10);
		ew.setBackground(Color.WHITE);
		ew.setBounds(350, 579, 290, 43);
		contentPane.add(ew);
		
		JLabel lblAddMedicine = new JLabel("ADD MEDICINE");
		lblAddMedicine.setOpaque(true);
		lblAddMedicine.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblAddMedicine.setBackground(new Color(255, 222, 173));
		lblAddMedicine.setBounds(0, 33, 369, 76);
		contentPane.add(lblAddMedicine);
		
		ty = new JTextField();
		ty.setFont(new Font("Tahoma", Font.BOLD, 19));
		ty.setColumns(10);
		ty.setBackground(Color.WHITE);
		ty.setBounds(350, 475, 290, 43);
		contentPane.add(ty);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("TYPE");
		lblNewLabel_1_2_1.setOpaque(true);
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1_2_1.setBackground(new Color(255, 222, 173));
		lblNewLabel_1_2_1.setBounds(0, 464, 273, 65);
		contentPane.add(lblNewLabel_1_2_1);
	}
}
