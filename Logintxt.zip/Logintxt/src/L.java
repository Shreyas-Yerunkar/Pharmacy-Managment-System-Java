import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Random;
import java.util.prefs.Preferences;
import java.awt.event.ActionEvent;

public class L extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					L frame = new L();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
public void close() {
		
		WindowEvent closeWindow = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}

LocalDate todayDate = LocalDate.now();
LocalDate t = todayDate.plusDays(2);
String date =t.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));


	/**
	 * Create the frame.
	 */
	public L() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 756, 773);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSelectTimeSlot = new JLabel("SELECT TIME SLOT");
		lblSelectTimeSlot.setOpaque(true);
		lblSelectTimeSlot.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblSelectTimeSlot.setBackground(new Color(255, 222, 173));
		lblSelectTimeSlot.setBounds(0, 141, 369, 76);
		contentPane.add(lblSelectTimeSlot);
		
		JLabel lblNewLabel = new JLabel("CHECK OUT");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setBackground(new Color(255, 222, 173));
		lblNewLabel.setBounds(0, 0, 745, 84);
		contentPane.add(lblNewLabel);
		
		JComboBox d = new JComboBox();
		d.setForeground(new Color(0, 0, 0));
		d.setBackground(new Color(255, 255, 255));
		d.setFont(new Font("Tahoma", Font.BOLD, 20));
		d.setMaximumRowCount(0);
		d.setModel(new DefaultComboBoxModel(new String[] {"7-9AM", "9-11AM", "11-12AM", "12-2PM", "2-4PM", "4-6PM", "6-8PM", "8-10PM"}));
		d.setBounds(0, 300, 260, 69);
		contentPane.add(d);
		
		JButton btnNewButton = new JButton("DONE");
		btnNewButton.setBackground(new Color(255, 222, 173));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ch=JOptionPane.showConfirmDialog(null, "Is the selected time slot correct ","Time Slot",JOptionPane.YES_NO_OPTION);
				if(ch==0) {
					Random x =new Random();
					int y=x.nextInt(100000);
			
					
				String s=(String) d.getSelectedItem();	

				String filepath= "D:\\java project\\orderdata\\orderdata.txt";
				File f=new File(filepath);
				try {
					PrintWriter pw = new PrintWriter(new FileWriter(f,true));
					pw.write("\n");
					pw.write("Time Slot: "+s);
					pw.write("\n");
					pw.write("Order No.:\n"+y);
					pw.write("\n");
					pw.write("Delivery/Collect By:"+date);
					pw.write("\n");
					pw.write("***END OF ORDER***");
					pw.close();
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
				
				
				File f1 = new File("D:\\java project\\receipt\\receipt.txt");
				
				try {
					FileWriter fw = new FileWriter(f1.getAbsoluteFile(),true);
					
					fw.write("\n");
					fw.write("Time Slot: "+s);
					fw.write("\n");
					fw.write("Order No.:"+y);
					fw.write("\n");
					fw.write("Delivery/Collect By :"+date);
					fw.write("\n\n");
					fw.close();
					
		               fw.close();
		             
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

					
				JOptionPane.showMessageDialog(null, "YOUR ORDER NUMBER IS :"+y);}
				
			    
			     JOptionPane.showMessageDialog(null, "YOUR ORDER WILL BE DELIVERED/CAN BE COLLECTED BY :"+date);

					

					close();
					Re d= new Re();
					d.setVisible(true);
					

					
			}
		});
		btnNewButton.setBounds(243, 562, 192, 69);
		contentPane.add(btnNewButton);
	}
}
