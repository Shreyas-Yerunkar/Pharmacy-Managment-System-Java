import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;

import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataInput;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Date;
import java.util.Scanner;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.awt.event.ActionEvent;

public class Userr extends JFrame {

	private JPanel contentPane;
	private JTextField b;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Userr frame = new Userr();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

 
 
	File f= new File("D:\\java project\\orderdata");
	private JTextField w;
	private JTextField r;
	private JLabel lblNewLabel_2;
	


	
	
void f() {
	
		boolean t=false;
		
		try {
			try (RandomAccessFile raf = new RandomAccessFile(f+"\\orderdata.txt","r")) {
				raf.readLine();
				String g=w.getText().toString();
				
				while(raf.getFilePointer() < raf.length()) {
					
					if(raf.readLine().toString().equals(g)){
						
						raf.skipBytes(20);  
						String h=raf.readLine().toString();
					JOptionPane.showMessageDialog(null, "Order Found");
					b.setText(h);
					if(b.getText().equals(r.getText())) {
						JOptionPane.showMessageDialog(null, "Order Has Been Delivered");
					}
					
					else {
						
						JOptionPane.showMessageDialog(null, " Order Has Not Been Delivered");
					}
					
					t=false;
					break;
					
					 }
					
					
					else {
					t=true;
					}					
					 
					
				}
				
				if(t==true) {
					JOptionPane.showMessageDialog(null, "Order Not Found");
					
				}
				
			
			} catch (HeadlessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}


	/**
	 * Create the frame.
	 */
	public Userr() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 753, 760);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("TRACK ORDER");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setBackground(new Color(255, 218, 185));
		lblNewLabel.setBounds(0, 0, 739, 130);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Check Order ");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnNewButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				SimpleDateFormat s=new SimpleDateFormat("yyyy/MM/dd");
				Date d=new Date();
				r.setText(s.format(d));
				
				f();	
				
				
				
			}
		});
		btnNewButton.setBounds(231, 487, 241, 57);
		contentPane.add(btnNewButton);
		
		b = new JTextField();
		b.setFont(new Font("Tahoma", Font.BOLD, 22));
		b.setBounds(257, 331, 224, 38);
		contentPane.add(b);
		b.setColumns(10);
		b.setEditable(false);
		
		w = new JTextField();
		w.setFont(new Font("Tahoma", Font.BOLD, 22));
		w.setBounds(257, 225, 224, 38);
		contentPane.add(w);
		w.setColumns(10);
		
		r = new JTextField();
		r.setFont(new Font("Tahoma", Font.BOLD, 22));
		r.setBounds(540, 0, 199, 62);
		contentPane.add(r);
		r.setColumns(10);
		r.setEditable(false);
		
		JLabel lblNewLabel_1 = new JLabel("ORDER NO.");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel_1.setBounds(0, 216, 230, 62);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("DELIVERY DATE");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel_2.setBounds(0, 322, 230, 62);
		contentPane.add(lblNewLabel_2);
	}
}
